<?php
/**
 * Add a user to a mailchimp mailing list
 * @package Joomla
 * @subpackage Fabrik
 * @author Rob Clayburn
 * @copyright (C) Rob Clayburn
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

//require the abstract plugin class
require_once(COM_FABRIK_FRONTEND.DS.'models'.DS.'plugin-form.php');
require_once(COM_FABRIK_FRONTEND.DS.'plugins'.DS.'form'.DS.'mailchimp'.DS.'MCAPI.class.php');

class FabrikModelMailchimp extends FabrikModelFormPlugin
{

	var $_counter = null;

	var $html = null;
	/**
	 * Constructor
	 */

	function __construct()
	{
		parent::__construct();
	}

	/**
	 * set up the html to be injected into the bottom of the form
	 *
	 * @param object $params (no repeat counter stuff needed here as the plugin manager
	 * which calls this function has already done the work for you
	 */

	function getBottomContent(&$params)
	{
			$this->html = "
			<label><input type=\"checkbox\" name=\"fabrik_mailchimp_signup\" class=\"fabrik_mailchimp_signup\" value=\"1\"  />
			 ".$params->get('mailchimp_signuplabel') . "</label>";

	}

	/**
	 * inject custom html into the bottom of the form
	 * @param int plugin counter
	 * @return string html
	 */

	function getBottomContent_result($c)
	{
		return $this->html;
	}

	/**
	 * process the plugin, called when form is submitted
	 *
	 * @param object $params
	 * @param object form
	 */

	function onAfterProcess($params, &$formModel)
	{
		$emailData =& $this->getEmailData();
		$post = JRequest::get('post');
		if (!array_key_exists('fabrik_mailchimp_signup', $post)) {
			return;
		}
		$listId = $params->get('mailchimp_listid');
		$api = new MCAPI($params->get('mailchimp_apikey'));
		$email = $emailData[FabrikString::safeColNameToArrayKey($params->get('mailchimp_email'))];
		$fname = $emailData[FabrikString::safeColNameToArrayKey($params->get('mailchimp_firstname'))];
		$lname = $emailData[FabrikString::safeColNameToArrayKey($params->get('mailchimp_lastname'))];

		$opts = array();
		$opts['FNAME'] = $fname;
		$opts['LNAME'] = $lname;

		// By default this sends a confirmation email - you will not see new members
		// until the link contained in it is clicked!
		$retval = $api->listSubscribe($listId, $email, $opts);

		if ($api->errorCode){
			JError::raiseNotice(500, $api->errorCode.':'.$api->errorMessage);
			return false;
		} else {
			return true;
		}

	}
}
?>