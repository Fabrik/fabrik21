<?php

/**
 * Observe other table plugins
 * @package Joomla
 * @subpackage Fabrik
 * @author Rob Clayburn
 * @copyright (C) Rob Clayburn
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

//require the abstract plugin class
require_once(COM_FABRIK_FRONTEND . DS . 'models' . DS . 'plugin-table.php');
require_once(COM_FABRIK_FRONTEND . DS . 'helpers' . DS . 'html.php');

//@TODO this doesnt work if you have a module on the same page pointing to the same table

class FabrikModelDecrypt extends FabrikModelTablePlugin
{

	var $_counter = null;

	/**
	 * Constructor
	 */

	function __construct()
	{
		parent::__construct();
	}

	/**
	 * (non-PHPdoc)
	 * @see FabrikModelTablePlugin::getAclParam()
	 */

	function getAclParam()
	{
		return 'php_decrypt_access';
	}

	/**
	 * determine if the table plugin is a button and can be activated only when rows are selected
	 * @return bol
	 */

	function canSelectRows()
	{
		return false;
	}

	/**
	 * run when the table loads its data(non-PHPdoc)
	 * @see components/com_fabrik/models/FabrikModelTablePlugin#onLoadData($params, $oRequest)
	 */
	function onLoadData(&$params, &$model)
	{
		if (JRequest::getVar('test') == 1) {
			echo "<pre>";print_r($model->_data);echo "</pre>";
		}
	}

	/**
	 * show a new for entering the form actions options
	 */

	function renderAdminSettings($elementId, &$row, &$params, $lists, $c)
	{
		$params->_counter_override = $this->_counter;
		$display = ($this->_adminVisible) ? "display:block" : "display:none";
		$return = '<div class="page-' . $elementId . ' elementSettings" style="' . $display . '">
 		' . $params->render('params', '_default', false, $c) . '</div>
 		';
		$return = str_replace("\r", "", $return);
		return $return;
	}

}
?>